function kneePoint = angleFcn(fval)
    len = size(fval,1);
    angleNode = [];
    extNod(1,1) = max(fval(:,1)) + 0.005;
    extNod(1,2) = max(fval(:,2)) + 0.005;
    for nodei = 1:len-1
        if nodei == 1
            angle1 =  angleFcn2(fval(nodei,:),fval(nodei,:),fval(nodei+1,:),1,extNod);
            angle2 = angleFcn2(fval(nodei,:),fval(nodei,:),fval(nodei+1,:),1,extNod);
            angle3 =  angleFcn2(fval(nodei,:),fval(nodei,:),fval(nodei+2,:),1,extNod);
            angle4 =  angleFcn2(fval(nodei,:),fval(nodei,:),fval(nodei+2,:),1,extNod);
            angleNode(nodei,1) = angle1;
            angleNode(nodei,2) = angle2;
            angleNode(nodei,3) = angle3;
            angleNode(nodei,4) = angle4;
        elseif nodei == 2
            angle1 =  angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei+1,:),0,extNod);
            angle2 =  angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei+2,:),0,extNod);
            angle3 = angle2;
            angle4 = angle2;
            angleNode(nodei,1) = angle1;
            angleNode(nodei,2) = angle2;
            angleNode(nodei,3) = angle3;
            angleNode(nodei,4) = angle4;
        elseif nodei == len-1
            angle1 = angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei+1,:),0,extNod);
            angle2 =  angleFcn2(fval(nodei,:),fval(nodei-2,:),fval(nodei+1,:),0,extNod);
            angle3 = angle2;
            angle4 = angle2;
            angleNode(nodei,1) = angle1;
            angleNode(nodei,2) = angle2;
            angleNode(nodei,3) = angle3;
            angleNode(nodei,4) = angle4;
        elseif nodei == len
            angle1 = angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei,:),2,extNod);
            angle2 = angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei,:),2,extNod);
            angle3 =  angleFcn2(fval(nodei,:),fval(nodei-2,:),fval(nodei,:),2,extNod);
            angle4 =  angleFcn2(fval(nodei,:),fval(nodei-2,:),fval(nodei,:),2,extNod);
            angleNode(nodei,1) = angle1;
            angleNode(nodei,2) = angle2;
            angleNode(nodei,3) = angle3;
            angleNode(nodei,4) = angle4;
        else
            angle1 = angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei+1,:),0,extNod);
            angle2 = angleFcn2(fval(nodei,:),fval(nodei-2,:),fval(nodei+1,:),0,extNod);
            angle3 = angleFcn2(fval(nodei,:),fval(nodei-1,:),fval(nodei+2,:),0,extNod);
            angle4 = angleFcn2(fval(nodei,:),fval(nodei-2,:),fval(nodei+2,:),0,extNod);
            angleNode(nodei,1) = angle1;
            angleNode(nodei,2) = angle2;
            angleNode(nodei,3) = angle3;
            angleNode(nodei,4) = angle4;
        end
    end
        [x y]=find(angleNode==max(max(angleNode)))
        nodeMax = x(1,1)
        kneePoint = fval(nodeMax,3);
end

function angle = angleFcn2(A,B,C,flag,extNod)
%A���м�ĵ㣬B����ߵģ�C���ұߵģ������x��
%�������û�е㣬��flag=1��Ҳ����B��A����ȵ�xֵ��y��һ��
%�����ұ�û�е㣬��flag=2��Ҳ����C��A����ȵ�yֵ��x��һ��
%flag=1ʱ�������B=A��ͬ����flag=2ʱ�������C=A
%����AB��AC֮���cos,Ȼ�󷴺����õ�ֵ
    if flag == 0
        A_x = A(1,1);
        A_y = A(1,2);
        B_x = B(1,1);
        B_y = B(1,2);
        C_x = C(1,1);
        C_y = C(1,2);
        AB_x = B_x-A_x;
        AB_y = B_y-A_y;
        AC_x = C_x-A_x;
        AC_y = C_y-A_y;
        ABmAC = AB_x * AC_x + AB_y * AC_y;  %AB��AC��������
        AB_mu = sqrt(AB_x * AB_x + AB_y * AB_y);
        AC_mu = sqrt(AC_x * AC_x + AC_y * AC_y);
        cosTheta = ABmAC / (AB_mu * AC_mu);
        Theta = acos(cosTheta);
        angle = rad2deg(Theta);
        %�����Ƿ���Ҫ��360��
        centerNod(1,1) = (B(1,1) + C(1,1))/2;
        centerNod(1,2) = (B(1,2) + C(1,2))/2;
        cenDis = sqrt( (extNod(1,1)-centerNod(1,1))^2 + (extNod(1,2)-centerNod(1,2))^2  );  %����ڵ㵽BC���Ľڵ�ľ���
        nodDis = sqrt( (extNod(1,1)-A(1,1))^2 + (extNod(1,2)-A(1,2))^2  );  %����ڵ㵽��ǰ��ǶȵĽڵ�ľ���
        k_AB = ( A(1,2)-B(1,2) )/( A(1,1)-B(1,1) );
        k_CA = ( C(1,2)-A(1,2) )/( C(1,1)-A(1,1) );
        if k_AB == k_CA
            angle = angle;
            angleFlag = 0;
        elseif cenDis <= nodDis 
            angle = 360 - angle;
            angleFlag = 1;
        else
            angle = angle;
            angleFlag = 2;
        end
        
    elseif flag == 1    %flag==1�������û�нڵ㣬
        A_x = A(1,1);
        A_y = A(1,2);
        B_x = B(1,1);
        B_y = B(1,2) + 0.005;
        C_x = C(1,1);
        C_y = C(1,2);
        AB_x = B_x-A_x;
        AB_y = B_y-A_y;
        AC_x = C_x-A_x;
        AC_y = C_y-A_y;
        ABmAC = AB_x * AC_x + AB_y * AC_y;
        AB_mu = sqrt(AB_x * AB_x + AB_y * AB_y);
        AC_mu = sqrt(AC_x * AC_x + AC_y * AC_y);
        cosTheta = ABmAC / (AB_mu * AC_mu);
        Theta = acos(cosTheta);
        angle = rad2deg(Theta);   
        %�����Ƿ���Ҫ��360��
        centerNod(1,1) = (B(1,1) + C(1,1))/2;
        centerNod(1,2) = (B(1,2) + C(1,2))/2;
        cenDis = sqrt( (extNod(1,1)-centerNod(1,1))^2 + (extNod(1,2)-centerNod(1,2))^2  );  %����ڵ㵽BC���Ľڵ�ľ���
        nodDis = sqrt( (extNod(1,1)-A(1,1))^2 + (extNod(1,2)-A(1,2))^2  );  %����ڵ㵽��ǰ��ǶȵĽڵ�ľ���
        k_AB = ( A(1,2)-B(1,2) )/( A(1,1)-B(1,1) );
        k_CA = ( C(1,2)-A(1,2) )/( C(1,1)-A(1,1) );
        if k_AB == k_CA
            angle = angle;
            angleFlag = 0;
        elseif cenDis <= nodDis 
            angle = 360 - angle;
            angleFlag = 1;
        else
            angle = angle;
            angleFlag = 2;
        end
    elseif flag == 2    %�ұ�û�ڵ�
        A_x = A(1,1);
        A_y = A(1,2);
        B_x = B(1,1);
        B_y = B(1,2);
        C_x = C(1,1) + 0.05;
        C_y = C(1,2);
        AB_x = B_x-A_x;
        AB_y = B_y-A_y;
        AC_x = C_x-A_x;
        AC_y = C_y-A_y;
        ABmAC = AB_x * AC_x + AB_y * AC_y;
        AB_mu = sqrt(AB_x * AB_x + AB_y * AB_y);
        AC_mu = sqrt(AC_x * AC_x + AC_y * AC_y);
        cosTheta = ABmAC / (AB_mu * AC_mu);
        Theta = acos(cosTheta);
        angle = rad2deg(Theta);
        %�����Ƿ���Ҫ��360��
        centerNod(1,1) = (B(1,1) + C(1,1))/2;
        centerNod(1,2) = (B(1,2) + C(1,2))/2;
        cenDis = sqrt( (extNod(1,1)-centerNod(1,1))^2 + (extNod(1,2)-centerNod(1,2))^2  );  %����ڵ㵽BC���Ľڵ�ľ���
        nodDis = sqrt( (extNod(1,1)-A(1,1))^2 + (extNod(1,2)-A(1,2))^2  );  %����ڵ㵽��ǰ��ǶȵĽڵ�ľ���
        k_AB = ( A(1,2)-B(1,2) )/( A(1,1)-B(1,1) );
        k_CA = ( C(1,2)-A(1,2) )/( C(1,1)-A(1,1) );
        if k_AB == k_CA
            angle = angle;
            angleFlag = 0;
        elseif cenDis <= nodDis 
            angle = 360 - angle;
            angleFlag = 1;
        else
            angle = angle;
            angleFlag = 2;
        end
    end
end
