function den = density(Network)
row = size(Network, 1);
col = size(Network, 2);
edg = 0;
Network(Network~=0)=1;
edg = sum(sum(Network));
den = (edg / 2.0) /((row * (row - 1.0)) / 2.0);
end