function xoverKids = crossover_cluster( parents, options, NVARS,  ...
    FitnessFcn, thisScore, thisPopulation );
    nKids = length( parents ) / 2;
    xoverKids = zeros( nKids, NVARS );
    index = 1;
    for i = 1:nKids
        r1 = thisPopulation( parents( index ), : );
        index = index + 1;
        r2 = thisPopulation( parents( index ), : );
        index = index + 1;
        for j = 1:size( r1, 2 )
            prob = rand;
            if ( prob > 0.5 )
                child( 1, j ) = r1( 1, j );
            else 
                child( 1, j ) = r2( 1, j );
            end 
        end 
        xoverKids( i, : ) = child;

    end 
% Decoded using De-pcode utility v1.2 from file /tmp/tmpwunMRz.p.
% Please follow local copyright laws when handling this file.

