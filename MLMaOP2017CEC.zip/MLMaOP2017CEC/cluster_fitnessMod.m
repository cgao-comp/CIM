function scores = cluster_fitnessMod( x, matrix )
   
    scores = zeros( size( x, 1 ), 1 );
    mod = 0;
    for numchrom = 1:size( x, 1 )
        CC = decodenew( x( numchrom, : ) );
        scores( numchrom ) =  - computeGain( CC, matrix );
    end 

    function mod = computeGain( CC, M )
        mod = 0;
        numEdges = sum( sum( M( :, : ) ) );
        for k = 1:size( CC, 2 )
            listnodes = CC{ k };
            ls = sum( sum( M( listnodes, listnodes ) ) );
            ds = sum( sum( M( listnodes, : ) ) );
            if ( ds > 0 )
                mod = mod + ( ls / numEdges - ( ds / numEdges ) ^ 2 );
            end 
        end 
    end 

end 

