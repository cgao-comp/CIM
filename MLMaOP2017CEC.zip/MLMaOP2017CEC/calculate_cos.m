% function cosMat = calculate_cos(simNet, alpha, matSiz)
%     nodSiz = size(simNet,1);
%     cosMat = zeros(nodSiz,nodSiz);
%     count = 1;
%     simTab = [];
%     for i = 1 : nodSiz
%         for j = i+1 : nodSiz      %���㣨1��1�������Ľڵ�
%             simTab(count,1) = i;
%             simTab(count,2) = j;
%             simTab(count,3) = simNet(i,j);
%             count = count + 1;
%         end
%     end
%     simTab = sortrows(simTab,-3);      %���ݵ��������� 
%     tabSiz = size(simTab,1);
%     lenTab = ceil(alpha * tabSiz);
%     simTab = simTab(1:lenTab,:);
%     for nod = 1:lenTab
%         nod1 = simTab(nod,1);
%         nod2 = simTab(nod,2);
%         simm = simTab(nod,3);
%         cosMat(nod1,nod2) = simm;
%         cosMat(nod2,nod1) = simm;
%     end
% end


% %%%new
function cosMat = calculate_cos(simTab, alpha, matSiz)
    nodSiz = size(simTab,1);
    cosMat = zeros(matSiz,matSiz);
    simTab = sortrows(simTab,-3); 
    tabSiz = size(simTab,1);
    lenTab = ceil(alpha * tabSiz);
    simTab = simTab(1:lenTab,:);
    for nod = 1:lenTab
        nod1 = simTab(nod,1);
        nod2 = simTab(nod,2);
        simm = simTab(nod,3);
        cosMat(nod1+1,nod2+1) = simm;
        cosMat(nod2+1,nod1+1) = simm;
    end
end
    