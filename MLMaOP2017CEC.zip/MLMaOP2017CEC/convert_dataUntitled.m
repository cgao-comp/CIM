A = load('CKM-Physicians-Innovation_multiplex.edges');
B = A(:,1:3);
C1 = B(:,1);
C2 = B(:,2);
C3 = B(:,3);
D = cat(2,C2,C3,C1)
fid = fopen('print_three.txt','w');
%fprintf(fid,'%d',B)
matrix = D;
[m,n] = size(matrix);
for i=1:1:m
    for j=1:1:n
        if j==n
            fprintf(fid,'%g\n',matrix(i,j));
        else
            fprintf(fid,'%g ',matrix(i,j));
        end
    end
end
fclose(fid);