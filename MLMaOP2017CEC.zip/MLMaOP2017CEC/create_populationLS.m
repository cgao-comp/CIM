
function pop = create_populationLS( NVARS, FitnessFcn, options, bestNeig, Neighbor, nettem )
totalPopulationSize = sum( options.PopulationSize );
embnum = totalPopulationSize;
pop = zeros( totalPopulationSize, NVARS );
rand( 'twister', sum( 25600 * clock ) );
prob = 0.5;
for emb = 1:embnum
    path = [nettem, '_', num2str(emb-1,'%d'), '_test_clusters(node2vec).txt'];
    Net = load(path);
    numcom = max(Net);
    Commofnod = ComNod(Net, NVARS, numcom);
    lencom = length(Commofnod);
    for numofnod = 1:NVARS
        for comm = 1:lencom
            if find(numofnod == Commofnod{1,comm})             
                lenthiscom = size(Commofnod{1,comm},1);         
                pop(emb,numofnod) = Commofnod{1,comm}(randi([1,lenthiscom]),1);     
            end
        end
    end
end
