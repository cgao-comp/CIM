function y = lincontest2(x)
%LINCONTEST2 objective function
%   From example of LINPROG (Optim toolbox)

%   Copyright 2003-2004 The MathWorks, Inc.

y = - ( 5*x(1) + 4*x(2) + 6*x(3) );