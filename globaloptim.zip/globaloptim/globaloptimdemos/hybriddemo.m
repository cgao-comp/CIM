%% Hybrid Scheme in the Genetic Algorithm

%   Copyright 2003-2015 The MathWorks, Inc.

%% Introduction
% This example shows how to use a hybrid scheme to optimize a function using the Genetic
% Algorithm and another optimization method. |ga| can reach the region near
% an optimum point relatively quickly, but it can take many function
% evaluations to achieve convergence. A commonly used technique is to run
% |ga| for a small number of generations to get near an optimum point. Then
% the solution from |ga| is used as an initial point for another optimization
% solver that is faster and more efficient for local search.

%% Rosenbrock's Function
% In this example we will optimize Rosenbrock's function (also known as
% Dejong's second function):
%
%     f(x)= 100*(x(2)-x(1)^2)^2+(1-x(1))^2
%
% This function is notorious in optimization because of the slow
% convergence most methods exhibit when trying to minimize this function.
% This function has a unique minimum at the point x* = (1,1) where it has a
% function value f(x*) = 0.
%
% We can view the code for this fitness function.
type dejong2fcn.m
%%
% We use the function |plotobjective| in the toolbox to plot the
% function |dejong2fcn| over the range = [-2 2;-2 2].
plotobjective(@dejong2fcn,[-2 2;-2 2]);

%% Genetic Algorithm Solution
% To start, we will use the Genetic Algorithm, |ga|, alone to find the
% minimum of Rosenbrock's function. We need to supply |ga| with a function
% handle to the fitness function |dejong2fcn.m|. Also, |ga| needs to know the
% how many variables are in the problem, which is two for this function.
FitnessFcn = @dejong2fcn;
numberOfVariables = 2;

%%
% Some plot functions can be selected to monitor the performance of the
% solver.
options = optimoptions(@ga,'PlotFcn',{@gaplotbestf,@gaplotstopping});

%%
% We set the random number stream for reproducibility, and run |ga| with the
% above inputs.
rng('default')
[x,fval] = ga(FitnessFcn,numberOfVariables,[],[],[],[],[],[],[],options)

%%
% The global optimum is at x* = (1,1). |ga| found a point near the optimum,
% but could not get a more accurate answer with the default stopping
% criteria. By changing the stopping criteria, we might find a more
% accurate solution, but it may take many more function evaluations to
% reach x* = (1,1). Instead, we can use a more efficient local search that
% starts where |ga| left off. The hybrid function field in |ga| provides this
% feature automatically.

%% Adding a Hybrid Function
% We will use a hybrid function to solve the optimization problem, i.e.,
% when |ga| stops (or you ask it to stop) this hybrid function will start
% from the final point returned by |ga|. Our choices are |fminsearch|,
% |patternsearch|, or |fminunc|. Since this optimization example is smooth,
% i.e., continuously differentiable, we can use the |fminunc| function from
% Optimization Toolbox as our hybrid function. Since |fminunc| has its
% own options structure, we provide it as an additional argument when
% specifying the hybrid function.
fminuncOptions = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton');
options = optimoptions(options,'HybridFcn',{@fminunc, fminuncOptions});

%%
% Run |ga| solver again with |fminunc| as the hybrid function.
[x,fval] = ga(@dejong2fcn,numberOfVariables,[],[],[],[],[],[],[],options)

%%
% The first plot shows the best and mean values of the population in every
% generation. The best value found by |ga| when it terminated is also shown
% in the plot title. When |ga| terminated, |fminunc| (the hybrid function) was
% automatically called with the best point found by |ga| so far. The solution
% |x| and |fval| is the result of using |ga| and |fminunc| together. As shown
% here, using the hybrid function can improve the accuracy of the
% solution efficiently.

displayEndOfDemoMessage(mfilename)
