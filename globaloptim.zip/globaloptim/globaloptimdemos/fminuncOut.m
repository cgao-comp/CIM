function stop = fminuncOut(~,optimvalues, state)
%fminuncOut output function used in nonSmoothOpt demo.

%   Copyright 2005-2011 The MathWorks, Inc.

persistent gaIter
stop = false;
fig = findobj(0,'type','figure','name','Genetic Algorithm');
if ~isempty(fig)
    set(0,'CurrentFigure',fig);
else
    return;
end

switch state
    case 'init'
        limits = get(gca,'XLim');
        gaIter = limits(2);
        hold on;
    case 'iter'
        set(gca,'Xlim', [0 optimvalues.iteration + gaIter]);
        fval = optimvalues.fval;
        iter = gaIter + optimvalues.iteration;
        plot(iter,fval,'dr')
        title(['Best function value: ',num2str(fval)],'interp','none')
    case 'done'
        fval = optimvalues.fval;
        title(['Best function value: ',num2str(fval)],'interp','none')
        % Create legend
        legend(findMarkerHandles(gca),...
            {'GA','FMINUNC hybrid'}, ...
            'Location','NorthEast');
        hold off
end

function markerHandles = findMarkerHandles(axis_handle)
% Helper function that returns one marker from the GA minimum fitness plot, 
% and one marker from the fminunc-hybrid plot
gaMarkers = findobj(axis_handle, 'Marker','v');
fminuncMarkers = findobj(axis_handle, 'Marker','diamond');
markerHandles = [gaMarkers(1), fminuncMarkers(1)];