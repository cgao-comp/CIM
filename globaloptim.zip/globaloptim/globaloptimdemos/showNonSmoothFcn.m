function [ah,sh] = showNonSmoothFcn(fcn,range)
%showNonSmoothFcn plot a fitness function

%   Copyright 2005-2011 The MathWorks, Inc.

pts = 25;
span = diff(range')/(pts - 1);
x = range(1,1): span(1) : range(1,2);
y = range(2,1): span(2) : range(2,2);

pop = zeros(pts * pts,2);
k = 1;
for i = 1:pts
    for j = 1:pts
        pop(k,:) = [x(i),y(j)];
        k = k + 1;
    end
end

try
    values = feval(fcn,pop);
catch %#ok<CTCH>
    for i = 1:size(pop,1)
        values(i) = feval(fcn,pop(i,:)); %#ok<AGROW>
    end
end
values = reshape(values,pts,pts);

% Plot smooth and non-smooth surfaces using different colors.  The
% non-smooth region takes different shades of yellow, and smooth regions
% takes different shades of cyan.  This is controlled with a color map
% where the minimum shade is minShade, and the number of shades is
% numShades
minShade = 0.3; numShades = 16;
% Create custom color map
customMap = [linspace(minShade,1,numShades)',linspace(minShade,1,numShades)',zeros(numShades,1);
          zeros(numShades,1),linspace(minShade,1,numShades)',linspace(minShade,1,numShades)'];
colormap(customMap);

% Color information is mapped from the surface Z value to the custom color
% map
normalizeZ = @(zVals)(zVals-min(min(zVals)))/max(max((zVals-min(min(zVals)))));
map2Colormap = @(cVals)minShade+(1-minShade)*normalizeZ(cVals);

% Plot non-smooth part
nonSmoothPart = values(:,x>=-3);
nonSmoothColorRGB = zeros([size(nonSmoothPart), 3]);
nonSmoothColorRGB(:,:,[1,2]) = repmat(map2Colormap(nonSmoothPart),[1 1 2]);
ah = axes;
sh(1) = surf(ah,x(x>=-3),y,nonSmoothPart,nonSmoothColorRGB);
hold on

% Plot smooth part
smoothPart = values(:,x<=-3);
smoothColorRGB = zeros([size(smoothPart), 3]);
smoothColorRGB(:,:,[2,3]) = repmat(map2Colormap(smoothPart),[1 1 2]);
sh(2) = surf(ah,x(x<=-3),y,smoothPart,smoothColorRGB);

% Adjust visualization
shading interp
light('Position',[-10 0 35])
lighting phong
contour(ah,x(x<=-3),y,0.5+0.5*normalizeZ(smoothColorRGB(:,:,2)));
contour(ah,x(x>=-3),y,0.5*normalizeZ(nonSmoothColorRGB(:,:,2)));
rotate3d on
view(37,60)
rotate3d off
