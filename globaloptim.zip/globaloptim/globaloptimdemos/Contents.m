% Global Optimization Toolbox Demos
%
% Global Search and Multi Start Demos
%   opticalInterferenceDemo  - Maximizing an optical interference pattern using
%                             GlobalSearch and MultiStart.
%
% Genetic Algorithm Demos
%   gafitness                - Writing a fitness function to use with GA.
%   gamultiobjfitness        - Performing a multiobjective optimization using 
%                              GAMULTIOBJ.
%   gaoptionsdemo            - Changing options for GA using GAOPTIMSET.
%   gamultiobjoptionsdemo    - Changing multiobjective genetic algorithm 
%                              options using GAOPTIMSET
%   hybriddemo               - Using a hybrid scheme in GA with Optimization 
%                              Toolbox.
%   gaconstrained            - Constrained minimization using GA.
%   steppedCantileverExample - Solving a mixed integer engineering design 
%                              problem using GA.
%
% Direct Search Demos
%   psobjective              - Writing an objective function to use with
%                              PATTERNSEARCH.
%   psoptionsdemo            - Changing options for PATTERNSEARCH using PSOPTIMSET.
%   psconstrained            - Constrained minimization using PATTERNSEARCH.
%   mtwashdemo               - Visual example showing how PATTERNSEARCH works.
%
% Particle Swarm Demos
%   ParticleSwarmExample     - Particle swarm example of setting options.
%
% Simulated Annealing Demos
%   saobjective              - Writing an objective function to use with
%                              SIMULANNEALBND.
%   saoptionsdemo            - Changing options for SIMULANNEALBND using OPTIMOPTIONS.
%   samultiprocessordemo     - Custom data type optimization using SIMULANNEALBND.
%
% Genetic Algorithm Examples
%   deterministicstudy       - A deterministic study of the GA options on
%                             performance.
%
% Pattern Search Examples
%   mtwashingtondemo         - Finding the highest mountain in White
%                              Mountains region using OPTIMTOOL interface.
%   mtwashdemo               - Find highest mountain in White Mountains
%                              using cell-mode demo
% Application Demos
%   nonSmoothOpt             - Optimization of Non-smooth Objective Function.
%   stochasticOpt            - Optimization of Stochastic Objective Function.
%
% Objective/fitness functions
%   ackleyfcn                - Compute the "Ackley" function.
%   dejong1fcn               - Compute DeJongs first function.
%   dejong2fcn               - Compute DeJongs second function.
%   dejong5fcn               - Compute DeJongs fifth function.
%   eggholder                - Compute "Eggholder" function.
%   rastriginsfcn            - Compute the "Rastrigin" function.
%   ps_example               - A discontinuous objective function.
%   lincontest2              - A linear objective function.
%   lincontest6              - A quadratic objective function.
%   lincontest7              - A quadratic objective function.
%   shufcn                   - Objective function with more than one minimum. 
%   discont_objective        - A discontinuous objective function.
%   simple_fitness           - A simple fitness function.
%   simple_objective         - A simple objective function.
%   simple_multiobjective    - A simple multiobjective fitness function.
%   parameterized_fitness    - A fitness function with additional
%                              parameters.
%   parameterized_objective  - An objective function with additional
%                              parameters.
%   vectorized_fitness       - A vectorized fitness function.
%   vectorized_objective     - A vectorized objective function.
%   vectorized_multiobjective- A vectorized multiobjective fitness function.
%   terrainfun               - Objective function for mtwashingtondemo.
%   kur_multiobjective       - Multiobjective fitness function
%   multirosenbrock.m        - Multidimensional Rosenbrock function (used by ParticleSwarmExample)
%
% Helper functions
%   plotobjective            - Plot a two dimensional fitness function.
%   psoutputwashington       - Draw 3-d terrain of the White Mountains 
%                              and search points
%   psplotwashington         - Draw contour map of the White Mountains,
%                              search points, and speed slider

%   Global Optimization Toolbox
%   Copyright 2016 The MathWorks, Inc.
%   $Revision  $  
