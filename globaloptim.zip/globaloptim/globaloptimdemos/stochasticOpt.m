%% Optimization of Stochastic Objective Function
% This example shows how to find a minimum of a stochastic objective 
% function using |patternsearch| function in the Global Optimization Toolbox. 
% We also show why the Optimization Toolbox(TM) functions are not 
% suitable for this kind of problems. A simple 2-dimensional optimization 
% problem is selected for this example to help visualize the objective function.

%   Copyright 2005-2015 The MathWorks, Inc.

%% Initialization
X0 = [2.5 -2.5];   % Starting point.
LB = [-5 -5];      % Lower bound
UB = [5 5];        % Upper bound
range = [LB(1) UB(1); LB(2) UB(2)];
Objfcn = @smoothFcn; % Handle to the objective function.
% Plot the smooth objective function
fig = figure('Color','w');
showSmoothFcn(Objfcn,range); 
hold on;
title('Smooth objective function');
ph = []; 
ph(1) = plot3(X0(1),X0(2),Objfcn(X0)+30,'or','MarkerSize',10,'MarkerFaceColor','r'); 
hold off;
ax = gca;
ax.CameraPosition = [-31.0391  -85.2792 -281.4265];
ax.CameraTarget = [0 0 -50];
ax.CameraViewAngle = 6.7937;
% Add legend information
legendLabels = {'Start point'};
lh = legend(ph,legendLabels,'Location','SouthEast');
lp = lh.Position; 
lh.Position = [1-lp(3)-0.005 0.005 lp(3) lp(4)];

%% Run |fmincon| on a Smooth Objective Function
% The objective function is smooth (twice continuously differentiable). We
% will solve the optimization problem using |fmincon| function from the
% Optimization Toolbox. |fmincon| finds a constrained minimum of a function
% of several variables. This function has a unique minimum at the point x*
% = (-5.0,-5) where it has a function value f(x*) = -250.

% Set options to display iterative results.
options = optimoptions(@fmincon,'Algorithm','active-set','Display','iter');
[Xop,Fop] = fmincon(Objfcn,X0,[],[],[],[],LB,UB,[],options)
figure(fig);
hold on;
% Plot the final point
ph(2) = plot3(Xop(1),Xop(2),Fop,'dm','MarkerSize',10,'MarkerFaceColor','m');
% Add legend to plot
legendLabels = [legendLabels, '|fmincon| solution'];
lh = legend(ph,legendLabels,'Location','SouthEast');
lp = lh.Position; 
lh.Position = [1-lp(3)-0.005 0.005 lp(3) lp(4)];
hold off;

%% Stochastic Objective Function
% The objective function we use now is the same as the previous example but
% with some random noise added to it. This is done by adding a random
% component to the function value. 

rng(0,'twister') % Reset the global random number generator
peaknoise = 4.5;
Objfcn = @(x) smoothFcn(x,peaknoise); % Handle to the objective function.
% Plot the objective function (non-smooth)
fig = figure('Color','w');
showSmoothFcn(Objfcn,range);
title('Stochastic objective function')
ax = gca;
ax.CameraPosition = [-31.0391  -85.2792 -281.4265];
ax.CameraTarget = [0 0 -50];
ax.CameraViewAngle = 6.7937;
%% Run |fmincon| on a Stochastic Objective Function
% The objective function is stochastic and not smooth. |fmincon| is a general
% constrained optimization solver which finds a local minima using first
% derivative of the objective function. If derivative of the objective
% function is not provided, |fmincon| uses finite difference to approximate
% first derivative  of the objective function. In this example, the
% objective function have some random noise in it. The derivatives hence
% could be highly unreliable. |fmincon| can potentially stop at a point which
% is not a minimum. This may happen because the optimal conditions seems to
% be satisfied at the final point because of noise or it could not make any
% progress.
options = optimoptions(@fmincon,'Algorithm','active-set','Display','iter');
[Xop,Fop] = fmincon(Objfcn,X0,[],[],[],[],LB,UB,[],options)
figure(fig);
hold on;
ph = []; 
ph(1) = plot3(X0(1),X0(2),Objfcn(X0)+30,'or','MarkerSize',10,'MarkerFaceColor','r');
ph(2) = plot3(Xop(1),Xop(2),Fop,'dm','MarkerSize',10,'MarkerFaceColor','m');
% Add legend to plot
legendLabels = {'Start point','|fmincon| solution'};
lh = legend(ph,legendLabels,'Location','SouthEast');
lp = lh.Position; 
lh.Position = [1-lp(3)-0.005 0.005 lp(3) lp(4)];
hold off;

%% Run |patternsearch|
% We will now use |patternsearch| from the Global Optimization Toolbox.
% Pattern search optimization techniques are a class of direct search methods 
% for optimization. A pattern search algorithm does not require any derivative 
% information of the objective function to find an optimal point.
PSoptions = optimoptions(@patternsearch,'Display','iter');
[Xps,Fps] = patternsearch(Objfcn,X0,[],[],[],[],LB,UB,PSoptions)
figure(fig);
hold on;
ph(3) = plot3(Xps(1),Xps(2),Fps,'dc','MarkerSize',10,'MarkerFaceColor','c');
% Add legend to plot
legendLabels = [legendLabels, 'Pattern Search solution'];
lh = legend(ph,legendLabels,'Location','SouthEast');
lp = lh.Position; 
lh.Position = [1-lp(3)-0.005 0.005 lp(3) lp(4)];
hold off
%%
% Pattern search algorithm is not affected by random noise in the objective
% functions. Pattern search requires only function value and not the
% derivatives, hence noise (of some uniform kind) may not affect it.
% However, pattern search requires more function evaluation to find the
% true minimum than derivative based algorithms, a cost for not using the
% derivatives.

displayEndOfDemoMessage(mfilename)
