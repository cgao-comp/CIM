function [x, fval, exitflag, output] = threshacceptbnd(FUN, x0, lb, ub, options)
%THRESHACCEPTBND is obsolete. Use SIMULANNEALBND instead.
%

%   Copyright 2006-2010 The MathWorks, Inc.

% This function is not supported any longer.
error(message('globaloptim:threshacceptbnd:notSupported'));
